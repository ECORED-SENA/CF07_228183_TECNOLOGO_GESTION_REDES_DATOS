function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6JhaQMpBV7j":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

